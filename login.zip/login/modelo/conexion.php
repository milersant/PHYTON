<?php

$conexion=new mysql("localhost","root","","login");
$conexion->set_charset("utf8");
?>